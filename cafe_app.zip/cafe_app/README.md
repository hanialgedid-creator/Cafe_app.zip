# نظام المقهى – المرحلة 1

## التشغيل (مرة واحدة فقط للإعداد)
1. ثبّت Flutter: https://docs.flutter.dev/get-started/install
2. افتح مجلد المشروع في الطرفية ونفّذ:
   flutter create --platforms=android --project-name cafe_app .
   flutter pub get
3. وصّل هاتف أندرويد (تصحيح USB) أو شغّل محاكي ثم:
   flutter run
4. لبناء ملف APK للتثبيت:
   flutter build apk --release
   الناتج: build/app/outputs/flutter-apk/app-release.apk

## الدخول
اسم المستخدم: admin — كلمة المرور: 1234  (غيّرها لاحقاً)

## ما تم إنجازه
- تسجيل الدخول بصلاحيات (مدير / كاشير / مطبخ)
- إدارة الفئات والمنتجات والمخزون (ضغطة مطولة على الفئة لحذفها)
- إدارة المستخدمين (للمدير فقط)
- قاعدة بيانات محلية SQLite
