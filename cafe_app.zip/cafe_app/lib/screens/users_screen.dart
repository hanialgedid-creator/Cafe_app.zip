import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../providers/auth_provider.dart';
import '../providers/menu_provider.dart';

class UsersScreen extends StatelessWidget {
  const UsersScreen({super.key});

  Future<void> _addUser(BuildContext context) async {
    final name = TextEditingController();
    final username = TextEditingController();
    final pass = TextEditingController();
    String role = 'cashier';
    String? error;

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('مستخدم جديد'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم')),
                TextField(controller: username, decoration: const InputDecoration(labelText: 'اسم المستخدم')),
                TextField(
                  controller: pass,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'كلمة المرور'),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: role,
                  decoration: const InputDecoration(labelText: 'الصلاحية'),
                  items: [
                    for (final e in kRoleLabels.entries)
                      DropdownMenuItem(value: e.key, child: Text(e.value)),
                  ],
                  onChanged: (v) => setS(() => role = v!),
                ),
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(error!, style: TextStyle(color: Theme.of(ctx).colorScheme.error)),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () async {
                if (name.text.trim().isEmpty || username.text.trim().isEmpty || pass.text.length < 4) {
                  setS(() => error = 'أكمل الحقول (كلمة المرور 4 أحرف على الأقل)');
                  return;
                }
                final err = await context
                    .read<MenuProvider>()
                    .addUser(name.text.trim(), username.text, pass.text, role);
                if (err != null) {
                  setS(() => error = err);
                } else if (ctx.mounted) {
                  Navigator.pop(ctx);
                }
              },
              child: const Text('إضافة'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final menu = context.watch<MenuProvider>();
    final me = context.watch<AuthProvider>().user!;

    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addUser(context),
        icon: const Icon(Icons.person_add),
        label: const Text('مستخدم'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.only(top: 8, bottom: 88),
        itemCount: menu.users.length,
        itemBuilder: (_, i) {
          final u = menu.users[i];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text(u.name),
              subtitle: Text('${u.username} • ${kRoleLabels[u.role] ?? u.role}'),
              trailing: u.id == me.id
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => menu.deleteUser(u.id!),
                    ),
            ),
          );
        },
      ),
    );
  }
}
