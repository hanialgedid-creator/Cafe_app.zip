import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../providers/auth_provider.dart';
import '../providers/menu_provider.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  int? _selectedCat;

  Future<void> _addCategory() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('فئة جديدة'),
        content: TextField(
          controller: c,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'اسم الفئة (مثال: مشروبات ساخنة)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إضافة')),
        ],
      ),
    );
    if (ok == true && c.text.trim().isNotEmpty && mounted) {
      await context.read<MenuProvider>().addCategory(c.text.trim());
    }
  }

  Future<bool> _confirm(String msg) async {
    final r = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(msg),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تأكيد')),
        ],
      ),
    );
    return r == true;
  }

  Future<void> _productDialog({Product? product}) async {
    final menu = context.read<MenuProvider>();
    if (menu.categories.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('أضف فئة أولاً')));
      return;
    }
    final name = TextEditingController(text: product?.name ?? '');
    final price = TextEditingController(text: product?.price.toString() ?? '');
    final stock = TextEditingController(text: (product?.stock ?? 0).toString());
    int catId = product?.categoryId ?? _selectedCat ?? menu.categories.first.id!;

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text(product == null ? 'منتج جديد' : 'تعديل المنتج'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم المنتج')),
                TextField(
                  controller: price,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'السعر'),
                ),
                TextField(
                  controller: stock,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'الكمية في المخزون'),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<int>(
                  value: catId,
                  decoration: const InputDecoration(labelText: 'الفئة'),
                  items: [
                    for (final c in menu.categories)
                      DropdownMenuItem(value: c.id, child: Text(c.name)),
                  ],
                  onChanged: (v) => setS(() => catId = v!),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () async {
                final p = double.tryParse(price.text.replaceAll(',', '.'));
                if (name.text.trim().isEmpty || p == null) return;
                await menu.saveProduct(Product(
                  id: product?.id,
                  name: name.text.trim(),
                  price: p,
                  categoryId: catId,
                  stock: int.tryParse(stock.text) ?? 0,
                ));
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final menu = context.watch<MenuProvider>();
    final isAdmin = context.watch<AuthProvider>().isAdmin;
    final items = menu.products
        .where((p) => _selectedCat == null || p.categoryId == _selectedCat)
        .toList();
    String catName(int id) =>
        menu.categories.where((c) => c.id == id).map((c) => c.name).firstOrNull ?? '';

    return Scaffold(
      floatingActionButton: isAdmin
          ? FloatingActionButton.extended(
              onPressed: () => _productDialog(),
              icon: const Icon(Icons.add),
              label: const Text('منتج'),
            )
          : null,
      body: Column(
        children: [
          SizedBox(
            height: 56,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ChoiceChip(
                    label: const Text('الكل'),
                    selected: _selectedCat == null,
                    onSelected: (_) => setState(() => _selectedCat = null),
                  ),
                ),
                for (final c in menu.categories)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: GestureDetector(
                      onLongPress: !isAdmin
                          ? null
                          : () async {
                              if (await _confirm('حذف الفئة "${c.name}" وكل منتجاتها؟')) {
                                if (_selectedCat == c.id) _selectedCat = null;
                                if (mounted) await menu.deleteCategory(c.id!);
                              }
                            },
                      child: ChoiceChip(
                        label: Text(c.name),
                        selected: _selectedCat == c.id,
                        onSelected: (_) => setState(() => _selectedCat = c.id),
                      ),
                    ),
                  ),
                if (isAdmin)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ActionChip(
                      avatar: const Icon(Icons.add, size: 18),
                      label: const Text('فئة'),
                      onPressed: _addCategory,
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? const Center(child: Text('لا توجد منتجات بعد'))
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 88),
                    itemCount: items.length,
                    itemBuilder: (_, i) {
                      final p = items[i];
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        child: ListTile(
                          title: Text(p.name),
                          subtitle: Text(
                            '${catName(p.categoryId)} • المخزون: ${p.stock}',
                            style: TextStyle(
                              color: p.stock <= 5 ? Theme.of(context).colorScheme.error : null,
                            ),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('${p.price.toStringAsFixed(2)} $kCurrency',
                                  style: const TextStyle(fontWeight: FontWeight.bold)),
                              if (isAdmin) ...[
                                IconButton(
                                  icon: const Icon(Icons.edit),
                                  onPressed: () => _productDialog(product: p),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline),
                                  onPressed: () async {
                                    if (await _confirm('حذف "${p.name}"؟')) {
                                      if (mounted) await menu.deleteProduct(p.id!);
                                    }
                                  },
                                ),
                              ],
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
