import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'products_screen.dart';
import 'users_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final isAdmin = auth.isAdmin;
    final pages = <Widget>[const ProductsScreen(), if (isAdmin) const UsersScreen()];

    return Scaffold(
      appBar: AppBar(
        title: Text('مرحباً ${auth.user!.name}'),
        actions: [
          IconButton(
            tooltip: 'تسجيل الخروج',
            icon: const Icon(Icons.logout),
            onPressed: () => context.read<AuthProvider>().logout(),
          ),
        ],
      ),
      body: pages[_index],
      bottomNavigationBar: isAdmin
          ? NavigationBar(
              selectedIndex: _index,
              onDestinationSelected: (i) => setState(() => _index = i),
              destinations: const [
                NavigationDestination(icon: Icon(Icons.local_cafe), label: 'المنتجات'),
                NavigationDestination(icon: Icon(Icons.people), label: 'المستخدمون'),
              ],
            )
          : null,
    );
  }
}
