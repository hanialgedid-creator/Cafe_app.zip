import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/models.dart';

String hashPassword(String p) => sha256.convert(utf8.encode(p)).toString();

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<Database> get db async => _db ??= await _open();

  Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'cafe.db');
    return openDatabase(path, version: 1, onCreate: (db, v) async {
      await db.execute('''
        CREATE TABLE users(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          username TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          role TEXT NOT NULL)''');
      await db.execute('''
        CREATE TABLE categories(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL)''');
      await db.execute('''
        CREATE TABLE products(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          price REAL NOT NULL,
          category_id INTEGER NOT NULL,
          stock INTEGER NOT NULL DEFAULT 0)''');
      // حساب المدير الافتراضي
      await db.insert('users', {
        'name': 'المدير',
        'username': 'admin',
        'password': hashPassword('1234'),
        'role': 'admin',
      });
    });
  }

  // ---------- المستخدمون ----------
  Future<AppUser?> login(String username, String password) async {
    final d = await db;
    final rows = await d.query('users',
        where: 'username = ? AND password = ?',
        whereArgs: [username.trim(), hashPassword(password)]);
    return rows.isEmpty ? null : AppUser.fromMap(rows.first);
  }

  Future<List<AppUser>> getUsers() async {
    final d = await db;
    return (await d.query('users', orderBy: 'id')).map(AppUser.fromMap).toList();
  }

  Future<void> addUser(String name, String username, String password, String role) async {
    final d = await db;
    await d.insert('users', {
      'name': name,
      'username': username.trim(),
      'password': hashPassword(password),
      'role': role,
    });
  }

  Future<void> deleteUser(int id) async {
    final d = await db;
    await d.delete('users', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- الفئات ----------
  Future<List<Category>> getCategories() async {
    final d = await db;
    return (await d.query('categories', orderBy: 'id')).map(Category.fromMap).toList();
  }

  Future<void> addCategory(String name) async {
    final d = await db;
    await d.insert('categories', {'name': name});
  }

  Future<void> deleteCategory(int id) async {
    final d = await db;
    await d.delete('products', where: 'category_id = ?', whereArgs: [id]);
    await d.delete('categories', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- المنتجات ----------
  Future<List<Product>> getProducts() async {
    final d = await db;
    return (await d.query('products', orderBy: 'name')).map(Product.fromMap).toList();
  }

  Future<void> addProduct(Product p) async {
    final d = await db;
    await d.insert('products', p.toMap());
  }

  Future<void> updateProduct(Product p) async {
    final d = await db;
    await d.update('products', p.toMap(), where: 'id = ?', whereArgs: [p.id]);
  }

  Future<void> deleteProduct(int id) async {
    final d = await db;
    await d.delete('products', where: 'id = ?', whereArgs: [id]);
  }
}
