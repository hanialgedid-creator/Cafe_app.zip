const String kCurrency = 'د.ل'; // غيّر العملة حسب بلدك

const Map<String, String> kRoleLabels = {
  'admin': 'مدير',
  'cashier': 'كاشير',
  'kitchen': 'مطبخ',
};

class AppUser {
  final int? id;
  final String name;
  final String username;
  final String role;
  AppUser({this.id, required this.name, required this.username, required this.role});

  factory AppUser.fromMap(Map<String, Object?> m) => AppUser(
        id: m['id'] as int?,
        name: m['name'] as String,
        username: m['username'] as String,
        role: m['role'] as String,
      );
}

class Category {
  final int? id;
  final String name;
  Category({this.id, required this.name});

  factory Category.fromMap(Map<String, Object?> m) =>
      Category(id: m['id'] as int?, name: m['name'] as String);
}

class Product {
  final int? id;
  final String name;
  final double price;
  final int categoryId;
  final int stock;
  Product({
    this.id,
    required this.name,
    required this.price,
    required this.categoryId,
    required this.stock,
  });

  factory Product.fromMap(Map<String, Object?> m) => Product(
        id: m['id'] as int?,
        name: m['name'] as String,
        price: (m['price'] as num).toDouble(),
        categoryId: m['category_id'] as int,
        stock: m['stock'] as int,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'price': price,
        'category_id': categoryId,
        'stock': stock,
      };
}
