import 'package:flutter/foundation.dart';
import '../data/database.dart';
import '../models/models.dart';

class MenuProvider extends ChangeNotifier {
  final _db = AppDatabase.instance;
  List<Category> categories = [];
  List<Product> products = [];
  List<AppUser> users = [];

  Future<void> load() async {
    categories = await _db.getCategories();
    products = await _db.getProducts();
    users = await _db.getUsers();
    notifyListeners();
  }

  Future<void> addCategory(String name) async {
    await _db.addCategory(name);
    await load();
  }

  Future<void> deleteCategory(int id) async {
    await _db.deleteCategory(id);
    await load();
  }

  Future<void> saveProduct(Product p) async {
    p.id == null ? await _db.addProduct(p) : await _db.updateProduct(p);
    await load();
  }

  Future<void> deleteProduct(int id) async {
    await _db.deleteProduct(id);
    await load();
  }

  Future<String?> addUser(String name, String username, String password, String role) async {
    try {
      await _db.addUser(name, username, password, role);
      await load();
      return null;
    } catch (_) {
      return 'اسم المستخدم موجود مسبقاً';
    }
  }

  Future<void> deleteUser(int id) async {
    await _db.deleteUser(id);
    await load();
  }
}
