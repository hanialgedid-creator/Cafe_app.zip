import 'package:flutter/foundation.dart';
import '../data/database.dart';
import '../models/models.dart';

class AuthProvider extends ChangeNotifier {
  AppUser? user;
  String? error;

  Future<bool> login(String username, String password) async {
    final u = await AppDatabase.instance.login(username, password);
    if (u == null) {
      error = 'اسم المستخدم أو كلمة المرور غير صحيحة';
      notifyListeners();
      return false;
    }
    error = null;
    user = u;
    notifyListeners();
    return true;
  }

  void logout() {
    user = null;
    notifyListeners();
  }

  bool get isAdmin => user?.role == 'admin';
}
